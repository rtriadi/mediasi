#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('122a21p9lt8q8jbc82sadth4n290mg8o', '::1', 1785769848, '__ci_last_regenerate|i:1785769842;user_id|s:1:\"1\";nama|s:21:\"Rahmat Triadi, S.Kom.\";role|s:5:\"admin\";roles|a:1:{i:0;s:5:\"admin\";}is_mediator|b:0;mediator_id|N;');


#
# TABLE STRUCTURE FOR: hasil_mediasi
#

DROP TABLE IF EXISTS `hasil_mediasi`;

CREATE TABLE `hasil_mediasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perkara_id` int(11) NOT NULL,
  `mediator_id` int(11) NOT NULL,
  `hasil` enum('berhasil','berhasil_sebagian','tidak_berhasil') NOT NULL,
  `file_laporan` varchar(255) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `tgl_hasil` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `perkara_id` (`perkara_id`),
  KEY `mediator_id` (`mediator_id`),
  CONSTRAINT `hasil_mediasi_ibfk_1` FOREIGN KEY (`perkara_id`) REFERENCES `perkara` (`id`),
  CONSTRAINT `hasil_mediasi_ibfk_2` FOREIGN KEY (`mediator_id`) REFERENCES `mediators` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: jenis_perkara
#

DROP TABLE IF EXISTS `jenis_perkara`;

CREATE TABLE `jenis_perkara` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: log_notifikasi
#

DROP TABLE IF EXISTS `log_notifikasi`;

CREATE TABLE `log_notifikasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perkara_id` int(11) DEFAULT NULL,
  `jenis` enum('email','wa') NOT NULL,
  `penerima` varchar(255) NOT NULL,
  `subjek` varchar(255) DEFAULT NULL,
  `pesan` text DEFAULT NULL,
  `status` enum('terkirim','gagal') NOT NULL DEFAULT 'gagal',
  `error_message` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: mediators
#

DROP TABLE IF EXISTS `mediators`;

CREATE TABLE `mediators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis` enum('hakim','non_hakim') NOT NULL,
  `no_sertifikat` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `mediators_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: perkara
#

DROP TABLE IF EXISTS `perkara`;

CREATE TABLE `perkara` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_perkara` varchar(50) NOT NULL,
  `jenis_perkara_id` int(11) NOT NULL,
  `nama_hakim` varchar(100) NOT NULL,
  `tgl_batas_mediasi` date NOT NULL,
  `status` enum('menunggu','proses','selesai') DEFAULT 'menunggu',
  `pp_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nomor_perkara` (`nomor_perkara`),
  KEY `jenis_perkara_id` (`jenis_perkara_id`),
  KEY `pp_id` (`pp_id`),
  CONSTRAINT `perkara_ibfk_1` FOREIGN KEY (`jenis_perkara_id`) REFERENCES `jenis_perkara` (`id`),
  CONSTRAINT `perkara_ibfk_2` FOREIGN KEY (`pp_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: perkara_mediator
#

DROP TABLE IF EXISTS `perkara_mediator`;

CREATE TABLE `perkara_mediator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perkara_id` int(11) NOT NULL,
  `mediator_id` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `tgl_assign` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `perkara_id` (`perkara_id`),
  KEY `mediator_id` (`mediator_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `perkara_mediator_ibfk_1` FOREIGN KEY (`perkara_id`) REFERENCES `perkara` (`id`),
  CONSTRAINT `perkara_mediator_ibfk_2` FOREIGN KEY (`mediator_id`) REFERENCES `mediators` (`id`),
  CONSTRAINT `perkara_mediator_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: perkara_pihak
#

DROP TABLE IF EXISTS `perkara_pihak`;

CREATE TABLE `perkara_pihak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perkara_id` int(11) NOT NULL,
  `jenis` enum('penggugat','tergugat','turut_tergugat') NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kuasa_hukum` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `urutan` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `perkara_id` (`perkara_id`),
  CONSTRAINT `perkara_pihak_ibfk_1` FOREIGN KEY (`perkara_id`) REFERENCES `perkara` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: ruangan
#

DROP TABLE IF EXISTS `ruangan`;

CREATE TABLE `ruangan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_ruangan` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sesi_mediasi
#

DROP TABLE IF EXISTS `sesi_mediasi`;

CREATE TABLE `sesi_mediasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perkara_id` int(11) NOT NULL,
  `mediator_id` int(11) NOT NULL,
  `tgl_mediasi` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `ruangan_id` int(11) DEFAULT NULL,
  `tempat_lain` varchar(200) DEFAULT NULL,
  `link_virtual` varchar(500) DEFAULT NULL COMMENT 'URL link virtual meeting',
  `platform_virtual` varchar(50) DEFAULT NULL COMMENT 'Zoom / Google Meet / MS Teams dll',
  `keterangan` text DEFAULT NULL,
  `status_sesi` enum('terjadwal','selesai','batal','dijadwal_ulang') NOT NULL DEFAULT 'terjadwal',
  `alasan_reschedule` text DEFAULT NULL COMMENT 'Alasan reschedule atau pembatalan',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mediator_id` (`mediator_id`),
  KEY `ruangan_id` (`ruangan_id`),
  KEY `idx_sesi_status` (`status_sesi`),
  KEY `idx_sesi_tgl` (`tgl_mediasi`),
  KEY `idx_sesi_perkara` (`perkara_id`),
  CONSTRAINT `sesi_mediasi_ibfk_1` FOREIGN KEY (`perkara_id`) REFERENCES `perkara` (`id`),
  CONSTRAINT `sesi_mediasi_ibfk_2` FOREIGN KEY (`mediator_id`) REFERENCES `mediators` (`id`),
  CONSTRAINT `sesi_mediasi_ibfk_3` FOREIGN KEY (`ruangan_id`) REFERENCES `ruangan` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (1, 'nama_aplikasi', 'SIPO-MEDIASI', '2026-08-02 18:57:36');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (2, 'slogan_aplikasi', 'Sistem Informasi Pengelolaan Mediasi Perkara', '2026-08-02 18:57:36');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (3, 'nama_satker', 'PA Gorontalo', '2026-08-02 18:59:41');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (4, 'logo_aplikasi', 'logo_1785668354.png', '2026-08-02 18:59:14');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (5, 'wa_notif_active', '0', '2026-08-02 19:08:28');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (6, 'wa_api_token', '', '2026-08-02 19:08:28');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (7, 'wa_api_url', 'https://api.fonnte.com/send', '2026-08-02 19:08:28');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (8, 'email_notif_active', '1', '2026-08-02 19:18:15');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (9, 'smtp_host', 'smtp.gmail.com', '2026-08-02 19:18:15');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (10, 'smtp_port', '587', '2026-08-02 19:18:15');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (11, 'smtp_user', 'surat@pa-gorontalo.go.id', '2026-08-03 20:54:36');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (12, 'smtp_pass', 'fbnd xuga dejt xllk', '2026-08-03 20:54:36');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (13, 'smtp_crypto', 'tls', '2026-08-02 19:18:15');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES (14, 'mail_from_name', 'SIPO-MEDIASI PA Gorontalo', '2026-08-02 19:18:15');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'pp',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `nama`, `username`, `password`, `role`, `is_active`, `created_at`, `updated_at`) VALUES (1, 'Rahmat Triadi, S.Kom.', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, '2026-08-03 23:10:36', '2026-08-03 23:10:36');


